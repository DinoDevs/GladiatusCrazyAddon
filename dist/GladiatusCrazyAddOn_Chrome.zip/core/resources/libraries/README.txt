Information about the libraries we are using

	Chart.js
		Website 	:	https://github.com/chartjs/Chart.js
		Version 	:	2.7.2
		File 		:	https://github.com/chartjs/Chart.js/releases/download/v2.7.2/Chart.min.js

	moment.js
		Website 	:	https://github.com/moment/moment
		Version 	:	2.22.2
		Zip 		:	https://github.com/moment/moment/archive/2.22.2.zip
		File		:	<zip>/moment-2.22.2/moment.js

	jquery.qrcode.js
		Website 	:	https://github.com/jeromeetienne/jquery-qrcode
		Version 	:	1.0
		Zip 		:	https://github.com/jeromeetienne/jquery-qrcode/archive/v1.0.zip
		File		:	<zip>/jquery-qrcode-1.0/jquery.qrcode.min.js
