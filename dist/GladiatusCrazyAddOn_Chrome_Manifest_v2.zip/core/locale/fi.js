/*
 * Gladiatus Crazy Addon Translation
 * Name : Finnish
 * Code : FI
 * Tag  : fi-FI
 * Translator: Dalmore
 */

// Languages Object
var gca_languages = gca_languages || {};

// Set Language
gca_languages["fi"] = {

	name : "Finnish (Finnish)",
	translators : ["Dalmore"],

	// Translations object
	locale : {
		
	}
}
